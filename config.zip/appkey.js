module.exports = {
    'kakao' : 'd0ff1e5cadeee0835c7561b6bb6914b7',
    'seoul' : '657a4f536373696d3539585656554c'
};

//JWT 키
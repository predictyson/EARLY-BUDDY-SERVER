const mysql = require('promise-mysql');

const dbConfig = {
    host: 'simjudbinstance.ckxkc0zkzjc8.ap-northeast-2.rds.amazonaws.com',
    port: 3306,
    user: 'simju1001',
    password: 'rzpq2963!!',
    database: 'theSpot',
    dateStrings : 'date'
}

module.exports = mysql.createPool(dbConfig);
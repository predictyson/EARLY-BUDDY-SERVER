const passport = require('passport');
const KakaoStrategy = require('passport-kakao').Strategy;
console.log(KakaoStrategy);
const pool = require('../app/module/pool');
const secret_config = require('../config/passportKey');


module.exports = () => {
    passport.serializeUser((user, done) => { // Strategy 성공 시 호출됨
        //사용자의 정보(user)가 세션에 저장
        done(null, user); // 여기의 user가 deserializeUser의 첫 번째 매개변수로 이동
    });

    passport.deserializeUser((user, done) => { // 매개변수 user는 serializeUser의 done의 인자 user를 받은 것
        //로그인에 성공하게 되면 Session정보를 저장을 완료했기에 이제 페이시 접근 시마다 사용자 정보를 갖게 Session에 갖게
        done(null, user);
    });

    passport.use(new KakaoStrategy({
        clientID: secret_config.federation.kakao.clientId,
        callbackURL: secret_config.federation.kakao.callbackUrl
    }, async (accessToken, refreshToken, profile, done) => {
        var _profile = profile._json;
        console.log('Kakao login info');
        console.info(_profile);

        try {
            await loginLogic({
                authType: 1,
                email: null,
                name: _profile.properties.nickname,
            }, done);
        } catch (err) {
            console.log("Kakao Error => " + err);
            done(err);
        }
    }));

    async function loginLogic(info, done) {
        console.log('process : ' + info.authType);

        const chkUserQuery = 'SELECT * FROM user WHERE name = ?';
        const insertUserQuery = 'INSERT INTO user (nickName, email, authType) VALUES (?, ?, ?)';

        const chkUserResult = await pool.queryParam_Arr(chkUserQuery, [info.name]);

        if (!chkUserResult) {
            return done(null, false, {
                message: "DB 에러"
            });
        } else if (chkUserResult.length == 1) { //기존 유저 로그인처리
            done(null, {
                idx: chkUserResult[0].userIdx
            });
        } else { //신규 유저 회원가입
            const insertUserResult = await pool.queryParam_Arr(insertUserQuery, [info.name, info.email, info.authType]);

            if (!insertUserResult) {
                return done(null, false, {
                    message: "DB 에러"
                });
            } else {
                done(null, {
                    idx: insertUserResult.insertId
                });
            }
        }
    }
};
module.exports = {
    federation: {
        kakao: {
            clientId: '41b70e4847ef6cfbab62f615c2b9a4e8',
            callbackUrl: '/user/kakaoSignin/callback'
        }
    }
};